Z=csvread('./file/output_SSTM.csv',1,2)
Idx=kmeans(Z,7)
csvwrite('./file/kmeans_SSTM.csv',Idx)